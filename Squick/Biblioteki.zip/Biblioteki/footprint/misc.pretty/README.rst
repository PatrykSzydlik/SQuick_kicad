KiCad Libraries
===============

This repository contains the KiCad libraries that are used by all Bricks
and Bricklets.

Usage
-----

You have to clone this repository (or symlink it) into the Brick/Bricklet 
design files you want to change. See the description of the Brick/Bricklet
you want to modify to see how this is done.
